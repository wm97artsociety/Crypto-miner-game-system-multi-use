# Miner Binaries

Precompiled mining executables for multiple platforms.

## Platforms
- Windows x86_64: cpuminer.exe
- Linux x86_64: cpuminer
- Linux ARM: cpuminer_arm
- Android ARM: cpuminer_android

## Usage
Run the appropriate binary with your mining pool config.

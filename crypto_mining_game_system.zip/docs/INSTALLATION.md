# Installation Guide

## PC / Linux / Steam Deck
1. Build and run the Unity app.
2. Run the miner binary appropriate for your platform.
3. Use the python wrapper to control mining.

## Android Phones/Tablets
1. Install the APK built from the Unity project.
2. Run the miner binary for Android.

## Consoles with Custom Firmware
1. Install Linux or Android on your console.
2. Sideload the Unity app APK or native Linux binaries.
3. Use the python wrapper or shell scripts to manage mining.

## Notes
- Mining performance will vary by device.
- Real mining is slow on non-ASIC hardware.

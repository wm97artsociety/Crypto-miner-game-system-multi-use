# Wallet Integration

This module contains example code and configuration for Bitcoin wallet and Lightning Network integration.
Supports testnet and mainnet wallets.
Includes QR code generation for wallet addresses.

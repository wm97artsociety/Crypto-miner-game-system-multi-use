import time

def simulate_mining(duration=60):
    print('Starting simulated mining for', duration, 'seconds...')
    for i in range(duration):
        print(f'Mining... {i+1} seconds elapsed')
        time.sleep(1)
    print('Simulation complete. Reward granted!')

if __name__ == '__main__':
    simulate_mining()

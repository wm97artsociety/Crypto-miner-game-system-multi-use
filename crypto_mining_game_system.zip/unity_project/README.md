# Unity Project for Fallout-Style Crypto Mining Game UI

This Unity project contains the source code and assets for a Pip-Boy inspired UI for a crypto mining game.

## How to build
- Open in Unity 2021.3 or later
- Target platform: Windows, Linux, Android
- Use included miner binaries and wrapper to connect UI with miner backend

## Features
- Real-time mining stats display
- Wallet address display
- Mining start/stop controls
- Upgradeable rigs and XP system
